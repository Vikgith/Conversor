//
//  ViewController.swift
//  Conversor
//
//  Created by Victor Alonso on 2018-11-14.
//  Copyright © 2018 Victor Alonso. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var changeEur : Double = 0.6683823862863363 * 100
    var changeDollar : Double = 1.496149540319571 * 100
    
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var moneyLabel: UILabel!
    
    @IBAction func changeToEur(_ sender: UIButton){
        convert(type: changeEur, symbol: "€")
    }
    
    @IBAction func changeToDollar(_ sender: UIButton){
        convert(type: changeDollar, symbol: "$")
    }
    
    func convert(type : Double, symbol : String){
        if var price = Double(textField.text!){
            price = (price * type).rounded()/100
            moneyLabel.text = "\(price) \(symbol)"
        }else {
            moneyLabel.text = "Invalid number"
        }
    }
    
}

