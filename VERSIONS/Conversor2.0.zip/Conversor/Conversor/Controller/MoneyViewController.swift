//
//  ViewController.swift
//  Conversor
//
//  Created by Victor Alonso on 2018-11-14.
//  Copyright © 2018 Victor Alonso. All rights reserved.
//

import UIKit
import SVProgressHUD
import ChameleonFramework
import SwiftyJSON
import Alamofire

class ViewController: UIViewController{
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getMoneyData(url: baseURL)
        
        textField.keyboardType = UIKeyboardType.decimalPad
        
        SVProgressHUD.setCornerRadius(25)
        SVProgressHUD.setBorderWidth(5)
    }
    
    //MARK: - Variables and Constants
    /***************************************************************/
    
    let APIKey = "02a9b6250b52e3c537cda831062b4f10"
    let baseURL = "http://data.fixer.io/api/latest?access_key=02a9b6250b52e3c537cda831062b4f10&symbols=CAD"
    
    var changeEur : Double = 0
    var changeDollar : Double = 0
    var date = ""
    
    //MARK: - IBOutlets, IBActions
    /***************************************************************/
    
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var moneyLabel: UILabel!
    @IBOutlet weak var updateLabel: UILabel!
    
    @IBAction func changeToEur(_ sender: UIButton){
        convert(type: changeEur, symbol: "€")
    }
    
    @IBAction func changeToDollar(_ sender: UIButton){
        convert(type: changeDollar, symbol: "$")
    }
    
    //MARK: - Convert money function
    /***************************************************************/
    
    func convert(type : Double, symbol : String){
        
            let currencyFormatter = NumberFormatter()
            currencyFormatter.usesGroupingSeparator = true
            currencyFormatter.numberStyle = .currency
            
            if symbol == "€" {
                currencyFormatter.locale = Locale(identifier: "es_ES")
            }else if symbol == "$" {
                currencyFormatter.locale = NSLocale.current
            }
            
        if var priceText = Double(textField.text!){
            priceText = (priceText * type * 100).rounded()/100
        
            let priceString = currencyFormatter.string(from: priceText as NSNumber)
            moneyLabel.text = priceString
            
        }else {
            SVProgressHUD.showError(withStatus: "Please insert value")
            SVProgressHUD.dismiss(withDelay: 0.7)
        }
    }
    
    //MARK: - Networking, Alamofire
    /***************************************************************/

    func getMoneyData(url: String) {

        Alamofire.request(url, method: .get).responseJSON {
            response in
            if response.result.isSuccess {
                //Succes, got the Money data
                self.updateMoneyData(json: JSON(response.result.value!))

            } else {
                //Error, No internet
                SVProgressHUD.showInfo(withStatus: "You don´t have internet")
                SVProgressHUD.dismiss(withDelay: 5)
                print("Error: \(String(describing: response.result.error))")
            }
        }
    }

    //MARK: - JSON Parsing
    /***************************************************************/

    func updateMoneyData(json : JSON) {
        
        if let valueCAD = json["rates"]["CAD"].double{
            
            date = json["date"].stringValue
            changeEur = 1/valueCAD
            changeDollar = valueCAD
            updateLabel.text = "last update: \(date)"
            
        }else {
            print("Error connection")
        }
    }
    
}

